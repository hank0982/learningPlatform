var config = {
    apiKey: "AIzaSyAg37CTypVABKtuv5LtS1bdWhgi5ioT-FQ",
    authDomain: "learning-platform-37f92.firebaseapp.com",
    databaseURL: "https://learning-platform-37f92.firebaseio.com",
    projectId: "learning-platform-37f92",
    storageBucket: "learning-platform-37f92.appspot.com",
    messagingSenderId: "546083116577"
};
module.exports = config